import GeneticAlgo as ga
import tetris as game
import Ai as ai
Test_iteration = 600
max_score = 200000
Test_List=[]
best_chromos = [-0.20041426, -0.60715724 ,-0.80930414 ,-0.36989255 , 0.68018247 ,-0.310204,0.89338506]
        
chromo = ga.Chromosome(best_chromos)
for e in range(Test_iteration): 
        
    game_statee=ai.run_tetris_game(chromo, speed=500, max_score=200000, no_show=False)
    print(f"\n Score in {e} iteration : ",game_statee[2])
    Test_List.append(game_statee[2])
    
    if game_statee[2] >= max_score:
        print("\n******** The game has reached the highest score ********")
        break

Max_Score = max(Test_List)
print("Max Score is : ",Max_Score)

with open('info.txt', 'a') as fd:
    fd.write(f"\n \n \nThe heighest score in test  = {Max_Score}\n")