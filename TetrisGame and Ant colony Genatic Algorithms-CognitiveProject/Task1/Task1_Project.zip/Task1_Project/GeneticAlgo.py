import random
import numpy as np
import copy
import tetris as game
import Ai as ai

class Chromosome():
    def __init__(self, weights):
        self.weights = weights
        self.score   = 0

    def calc_fitness(self, game_state):
        self.score = game_state[2] # Score

    # Select the best move based on the chromosome weights.
    def calc_best_move(self, board, piece, show_game = False):
        best_X     = 0          
        best_R     = 0          
        best_Y     = 0          
        best_score = -100000    

        # Calculate the total holes and blocks above holes before play
        holes, blocking_blocks = game.calc_initial_move_info(board)

        for r in range(len(game.PIECES[piece['shape']])):

            # Iterate through every possible rotation
            for x in range(-2,game.BOARDWIDTH-2):

                #Iterate through every possible position
                movement_info = game.calc_move_info(board, piece, x, r, holes, blocking_blocks)
 
                # Check if it's a valid movement
                if (movement_info[0]):
                    # Calculate movement score
                    movement_score = 0
                    for i in range(1, len(movement_info)):
                        movement_score += self.weights[i-1]*movement_info[i]

                    # Update best movement
                    if (movement_score > best_score):
                        best_score = movement_score
                        best_X = x
                        best_R = r
                        best_Y = piece['y']

        if (show_game):
            piece['y'] = best_Y
        else:
            piece['y'] = -2

        piece['x'] = best_X
        piece['rotation'] = best_R

        return best_X, best_R


class GeneticA:
    def __init__ (self, num_pop, num_weights=7, lb=-1, ub=1):
        self.chromosomes = []

        for i in range(num_pop):
            weights = np.random.uniform(lb, ub, size=(num_weights))
            chrom   = Chromosome(weights)
            self.chromosomes.append(chrom)

            # Evaluating fitness
            game_state = ai.run_tetris_game(self.chromosomes[i], 1000, 200000, True)
            self.chromosomes[i].calc_fitness(game_state)

    def __str__(self):
        for i, chromo in enumerate(self.chromosomes):
            print(f"Chromosome: {i+1}")
            print(f"    Score : {chromo.score}")
            print(f"  Weights : {chromo.weights}")

        return ''

    
    # Selection method using roulette wheel
    def selection(self, chromosomes, num_selection):
        fitness = np.array([chrom.score for chrom in chromosomes])
        norm_fitness  = fitness/fitness.sum()
        roulette_prob = np.cumsum(norm_fitness)
        pop_selected = []
        while len(pop_selected) < num_selection:
            pick = random.random()
            for index, individual in enumerate(self.chromosomes):
                if pick < roulette_prob[index]:
                    pop_selected.append(individual)
                    break

        return pop_selected

    # Create a new chromosome using arithmetic crossover
    def crossover(self, selected_pop,  cross_rate=0.4, mutation_rate=0.1):
        
        N_genes    = len(selected_pop[0].weights) # Chromosome size
        new_chromo = [copy.deepcopy(c) for c in selected_pop]

        for i in range(0, len(selected_pop), 2):
            a = random.random()

            parent_1 = random.randint(0,100)
            parent_2 = random.randint(0,100)
            if ( parent_1 < cross_rate * 100 and parent_2 < cross_rate*100):
                try:
                    for j in range(0, N_genes):
                        new_chromo[i].weights[j]   = a * new_chromo[i].weights[j] + (1 - a) * new_chromo[i+1].weights[j]

                        new_chromo[i+1].weights[j] = a * new_chromo[i+1].weights[j] + (1 - a) * new_chromo[i].weights[j]

                except IndexError:
                    pass

        return new_chromo

    # Apply mutation to a specific chromosome using random mutation
    def mutation(self, chromosome, mutation_rate):
        for chromo in chromosome:
            for i, point in enumerate(chromo.weights):
                if random.random() < mutation_rate:
                    chromo.weights[i] = random.uniform(-1.0, 1.0)
        return chromosome          
    
    # Replace chromosomes from population with the new ones
    def replace(self, new_chromo):
        new_pop = sorted(self.chromosomes, key=lambda x: x.score, reverse=True)
        new_pop[-(len(new_chromo)):] = new_chromo
        random.shuffle(new_pop)

        self.chromosomes = new_pop
