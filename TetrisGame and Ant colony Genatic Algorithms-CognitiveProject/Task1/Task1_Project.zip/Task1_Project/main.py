import GeneticAlgo as ga
import Ai as ai
import matplotlib.pyplot as plt
import copy
import random
import numpy as np

def main(no_show_game):
   
    random.seed(20)
    GAP            = 0.3
    SPEED          = 10000
    NUM_GENERATION = 350
    NUM_POPULATION = 15
    MUTATION_RATE  = 0.2
    CROSSOVER_RATE = 0.75
    MAX_SCORE      = 2000000
    NUM_CHILD      = round(NUM_POPULATION*GAP) 
    

    experiments   = []
    best_scores_1 = []    # Best score at each generation
    best_scores_2 = []    # Second best score at each generation
    generations   = []    # Initialize generation list

    # Initialize population
    init_pop = ga.GeneticA(NUM_POPULATION)

    # Make a copy from initial population so that we can run all experiments with the same initial population
    pop = copy.deepcopy(init_pop)

    for g in range(NUM_GENERATION):
        print (' \n')
        print (f' *********Iteration : {g}***********')
        print (' \n')

        # Save generation
        generations.append(copy.deepcopy(pop))

        pop.chromosomes.sort(key=lambda x: x.score, reverse=True)
        # Best score
        best_scores_1.append(pop.chromosomes[0].score) 

        # Second best score
        best_scores_2.append(pop.chromosomes[1].score)  

        # Keep best 3 chromosomes in population
        best_3 = pop.chromosomes[:3]

        # Select chromosomes using roulette method
        selected_pop = pop.selection(pop.chromosomes, NUM_CHILD)

        # Apply crossover and mutation
        new_chromo= pop.crossover(selected_pop,CROSSOVER_RATE,MUTATION_RATE)
        new_chromo =pop.mutation(new_chromo,MUTATION_RATE)
        new_chromo   = best_3 + new_chromo

        # for x in new_chromo:
        #     print(x.weights)

        for i in range(NUM_CHILD):
            # Run the game for each chromosome
            game_state = ai.run_tetris_game(pop.chromosomes[i], SPEED, MAX_SCORE, no_show_game)

            # Calculate the fitness
            new_chromo[i].calc_fitness(game_state)

        # Insert new children in pop
        pop.replace(new_chromo)
        fitness = [chrom.score for chrom in pop.chromosomes]
        print(fitness)

        # Print population
        print(pop)

    # Save experiments results
    experiments.append(generations)

    best_scores = [-float('inf'), -float('inf')]
    best_weights = [None, None]

    # get the best 2 chromosomes
    for exp in experiments:
        for gen in exp:
            for chrom in gen.chromosomes:
                with open('info.txt', 'a') as fd:
                    fd.write(f"score = {chrom.score}\n")
                    fd.write(f"Weights: {chrom.weights}\n\n")

                if chrom.score > best_scores[0] and chrom.score != best_scores[1]:
                    if best_weights[1] is None or not np.array_equal(chrom.weights, best_weights[1]):
                        best_scores[1]  = best_scores[0]
                        best_weights[1] = best_weights[0]
                        best_scores[0]  = chrom.score
                        best_weights[0] = chrom.weights

                elif chrom.score > best_scores[1] and chrom.score != best_scores[0]:
                    if best_weights[0] is None or not np.array_equal(chrom.weights, best_weights[0]):
                        best_scores[1]  = chrom.score
                        best_weights[1] = chrom.weights

    print(f'Best Score 1: {best_scores[0]}')
    print(f'Corresponding Weight 1: {best_weights[0]}')
    print(f'Best Score 2: {best_scores[1]}')
    print(f'Corresponding Weight 2: {best_weights[1]}')

    with open('info.txt', 'a') as fd:
        fd.write(f"\n \n \nThe heighest score = {best_scores[0]}\n")
        fd.write(f"Weights: {best_weights[0]}\n\n\n\n")

    best_indices = [-1, -1] 

    # Create a line plot to show the progress of the best 2 chromosomes 
    plt.figure(figsize=(10, 6))
    plt.plot(range(NUM_GENERATION), best_scores_1, label="Best Chromosome", linestyle='-', marker=None, color='g')
    plt.plot(range(NUM_GENERATION), best_scores_2, label="Second Best Chromosome", linestyle='-', marker=None, color='y')
    plt.xlabel("Generation")
    plt.ylabel("Score")
    plt.title("Scores of the Best Two Chromosomes Over Generations")
    plt.legend()  
    plt.savefig("best_two_chromosomes_progress.png", dpi=300)  
    plt.show()  # Display the plot

# Return the best two scores and their weights
    return best_weights[0]

if __name__ == "__main__":
    best_chromos = main(no_show_game=True)
