import random, time, pygame, sys
from pygame.locals import *
import tetris as tetris


# Set the screen size
screen_size = [640, 480]
screen = pygame.display.set_mode(screen_size)

def run_tetris_game(genome, speed, max_score=200000, no_show=False):
    tetris.FPS = int(speed)
    tetris.main()

    board = tetris.get_blank_board()
    last_fall_time = time.time()
    score = 0
    level, fall_freq = tetris.calc_level_and_fall_freq(score)
    falling_piece = tetris.get_new_piece()
    next_piece = tetris.get_new_piece()

    genome.calc_best_move(board, falling_piece)

    num_used_pieces = 0
    removed_lines = [0, 0, 0, 0]  

    alive = True
    win = False

    while alive:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("Game exited by user")
                exit()

        if falling_piece is None:
            falling_piece = next_piece
            next_piece = tetris.get_new_piece()

            genome.calc_best_move(board, falling_piece, no_show)

            num_used_pieces += 1
            score += 1

            last_fall_time = time.time()

            if not tetris.is_valid_position(board, falling_piece):
                alive = False

        if no_show or time.time() - last_fall_time > fall_freq:
            if not tetris.is_valid_position(board, falling_piece, adj_Y=1):
                tetris.add_to_board(board, falling_piece)

                num_removed = tetris.remove_complete_lines(board)
                if num_removed == 1:
                    score += 40
                    removed_lines[0] += 1
                elif num_removed == 2:
                    score += 120
                    removed_lines[1] += 1
                elif num_removed == 3:
                    score += 300
                    removed_lines[2] += 1
                elif num_removed == 4:
                    score += 1200
                    removed_lines[3] += 1

                falling_piece = None
            else:
                falling_piece['y'] += 1
                last_fall_time = time.time()

        if not no_show:
            draw_tetris_game(board, score, level, next_piece, falling_piece, genome)

        if score > max_score:
            alive = False
            win = True

    game_state = [num_used_pieces, removed_lines, score, win]

    return game_state

# Draw the Tetris game on the screen
def draw_tetris_game(board, score, level, next_piece, falling_piece, genome):
    tetris.DISPLAYSURF.fill(tetris.BGCOLOR)
    tetris.draw_board(board)
    tetris.draw_status(score, level)
    tetris.draw_next_piece(next_piece)

    if falling_piece is not None:
        tetris.draw_piece(falling_piece)

    pygame.display.update()
    tetris.FPSCLOCK.tick(tetris.FPS)
